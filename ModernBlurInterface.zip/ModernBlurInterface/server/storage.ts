import { notes, type Note, type InsertNote, type UpdateNote, users, type User, type InsertUser } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getNotes(isSecret: boolean): Promise<Note[]>;
  getNote(id: number): Promise<Note | undefined>;
  createNote(note: InsertNote): Promise<Note>;
  updateNote(id: number, note: UpdateNote): Promise<Note | undefined>;
  deleteNote(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private notes: Map<number, Note>;
  private userCurrentId: number;
  private noteCurrentId: number;

  constructor() {
    this.users = new Map();
    this.notes = new Map();
    this.userCurrentId = 1;
    this.noteCurrentId = 1;
    
    // Add some initial notes for the UI
    this.createNote({
      id: this.noteCurrentId,
      title: "Meeting Notes",
      content: "Discussed project timeline, key deliverables, and resource allocation. Need to follow up with Mark about design assets.",
      isSecret: false
    });
    
    this.createNote({
      id: this.noteCurrentId,
      title: "Shopping List",
      content: "1. Milk\n2. Eggs\n3. Bread\n4. Apples\n5. Coffee",
      isSecret: false
    });
    
    this.createNote({
      id: this.noteCurrentId,
      title: "Project Ideas",
      content: "- Mobile app for plant care\n- Recipe sharing platform\n- Fitness tracking tool with social features",
      isSecret: false
    });
    
    this.createNote({
      id: this.noteCurrentId,
      title: "Account Passwords",
      content: "Netflix: *********\nBanking: **********\nEmail: **********",
      isSecret: true
    });
    
    this.createNote({
      id: this.noteCurrentId,
      title: "Gift Ideas",
      content: "Mom: Jewelry\nDad: Hiking gear\nSister: Art supplies",
      isSecret: true
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getNotes(isSecret: boolean): Promise<Note[]> {
    return Array.from(this.notes.values()).filter(
      (note) => note.isSecret === isSecret
    );
  }

  async getNote(id: number): Promise<Note | undefined> {
    return this.notes.get(id);
  }

  async createNote(insertNote: InsertNote): Promise<Note> {
    const id = this.noteCurrentId++;
    const note: Note = { ...insertNote, id };
    this.notes.set(id, note);
    return note;
  }

  async updateNote(id: number, updateNote: UpdateNote): Promise<Note | undefined> {
    const existingNote = this.notes.get(id);
    
    if (!existingNote) {
      return undefined;
    }
    
    const updatedNote: Note = { ...existingNote, ...updateNote };
    this.notes.set(id, updatedNote);
    return updatedNote;
  }

  async deleteNote(id: number): Promise<boolean> {
    return this.notes.delete(id);
  }
}

export const storage = new MemStorage();
