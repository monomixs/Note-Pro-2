import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, LogOut, Lock, ShieldAlert } from "lucide-react";
import { useLocation } from "wouter";
import { NoteCard } from "@/components/ui/note-card";
import { useNotes } from "@/context/note-context";
import { NoteForm } from "@/components/ui/note-form";
import { Note } from "@shared/schema";

export default function SecretNotes() {
  const [location, setLocation] = useLocation();
  const { secretNotes, isLoading } = useNotes();
  const [showNewNoteForm, setShowNewNoteForm] = useState(false);
  const [viewNote, setViewNote] = useState<Note | null>(null);
  const [editNote, setEditNote] = useState<Note | null>(null);

  const handleViewNote = (note: Note) => {
    setViewNote(note);
  };

  const handleEditNote = (note: Note) => {
    setEditNote(note);
  };

  const exitSecretMode = () => {
    setLocation("/");
  };
  
  // Apply secret mode scrollbar to body
  useEffect(() => {
    document.body.classList.add("secret-mode-scrollbar");
    
    return () => {
      // Remove secret mode scrollbar when component unmounts
      document.body.classList.remove("secret-mode-scrollbar");
    };
  }, []);

  // Define animations
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: {
        when: "beforeChildren",
        staggerChildren: 0.1
      }
    },
    exit: {
      opacity: 0,
      filter: "blur(12px)",
      transition: { duration: 0.5 }
    }
  };

  const headerVariants = {
    hidden: { 
      opacity: 0, 
      y: -20 
    },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        type: "spring",
        damping: 15,
        stiffness: 300
      }
    }
  };

  const buttonVariants = {
    hidden: { 
      opacity: 0, 
      y: 20, 
      scale: 0.8
    },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: {
        type: "spring",
        damping: 12,
        stiffness: 200
      }
    },
    hover: { 
      scale: 1.05, 
      y: -5,
      boxShadow: "0 15px 30px rgba(239, 68, 68, 0.2)",
      transition: {
        type: "spring",
        damping: 10,
        stiffness: 300
      }
    },
    tap: { 
      scale: 0.95, 
      y: 0,
      transition: {
        type: "spring",
        damping: 15,
        stiffness: 400
      }
    }
  };

  const skeletonVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (custom: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: custom * 0.1,
        duration: 0.5
      }
    })
  };

  const emptyStateVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        delay: 0.2,
        duration: 0.6,
        ease: [0.23, 1, 0.32, 1]
      }
    }
  };

  const exitButtonVariants = {
    hover: { 
      scale: 1.05, 
      x: 5,
      transition: {
        type: "spring",
        damping: 10,
        stiffness: 300
      }
    },
    tap: { scale: 0.95, x: 0 },
    initial: { 
      opacity: 0, 
      x: 20 
    },
    animate: { 
      opacity: 1, 
      x: 0,
      transition: {
        type: "spring",
        damping: 15,
        stiffness: 300,
        delay: 0.3
      }
    }
  };

  return (
    <motion.div 
      className="fixed inset-0 z-40 bg-black p-6 overflow-auto secret-mode-scrollbar"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      exit="exit"
    >
      <div className="container mx-auto pt-20 pb-10">
        <motion.div 
          className="flex justify-between items-center mb-8"
          variants={headerVariants}
        >
          <motion.div 
            className="flex items-center"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ 
              type: "spring",
              damping: 20,
              stiffness: 300
            }}
          >
            <motion.div
              className="bg-red-500/20 p-2 rounded-full mr-3"
              animate={{ 
                scale: [1, 1.1, 1],
                boxShadow: [
                  "0 0 0 0 rgba(239, 68, 68, 0.7)",
                  "0 0 0 10px rgba(239, 68, 68, 0)",
                  "0 0 0 0 rgba(239, 68, 68, 0)"
                ]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                repeatType: "loop"
              }}
            >
              <ShieldAlert className="text-red-500" size={24} />
            </motion.div>
            <div>
              <h2 className="text-2xl font-heading font-bold text-red-500">
                Secret Notes 
              </h2>
              <motion.p 
                className="text-xs text-red-500/70"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                Secured & Private
              </motion.p>
            </div>
          </motion.div>
          
          <motion.button
            className="bg-gray-800 text-white p-3 rounded-lg hover:bg-gray-700 flex items-center"
            variants={exitButtonVariants}
            initial="initial"
            animate="animate"
            whileHover="hover"
            whileTap="tap"
            onClick={exitSecretMode}
            title="Exit Secure Mode"
          >
            <LogOut size={20} />
          </motion.button>
        </motion.div>
        
        <motion.div 
          className="flex justify-center mb-12"
          variants={buttonVariants}
        >
          <motion.button
            className="bg-gradient-to-r from-red-500 to-red-600 text-white px-8 py-4 rounded-xl font-medium shadow-lg transition-all"
            variants={buttonVariants}
            whileHover="hover"
            whileTap="tap"
            onClick={() => setShowNewNoteForm(true)}
          >
            <span className="flex items-center">
              <Plus className="mr-2" size={24} />
              New Secret Note
            </span>
          </motion.button>
        </motion.div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <motion.div 
                key={i} 
                className="bg-gray-800 p-5 rounded-xl shadow-md h-40"
                variants={skeletonVariants}
                custom={i}
                initial="hidden"
                animate="visible"
              >
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-700/30 rounded w-3/4 mb-3"></div>
                  <div className="h-3 bg-gray-700/20 rounded w-full mb-2"></div>
                  <div className="h-3 bg-gray-700/20 rounded w-5/6 mb-2"></div>
                  <div className="h-3 bg-gray-700/20 rounded w-4/6 mb-4"></div>
                  <div className="flex space-x-2">
                    <div className="h-6 w-6 bg-gray-700/30 rounded"></div>
                    <div className="h-6 w-6 bg-gray-700/30 rounded"></div>
                    <div className="h-6 w-6 bg-gray-700/30 rounded"></div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : secretNotes.length === 0 ? (
          <motion.div 
            className="text-center py-16"
            variants={emptyStateVariants}
          >
            <motion.div
              className="mb-8 flex justify-center"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ 
                type: "spring", 
                stiffness: 200, 
                damping: 15 
              }}
            >
              <motion.div
                className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center"
                animate={{ 
                  boxShadow: [
                    "0 0 0 0 rgba(239, 68, 68, 0.4)",
                    "0 0 0 20px rgba(239, 68, 68, 0)",
                    "0 0 0 0 rgba(239, 68, 68, 0)"
                  ]
                }}
                transition={{ 
                  duration: 2,
                  repeat: Infinity,
                  repeatType: "loop"
                }}
              >
                <Lock className="text-red-500" size={36} />
              </motion.div>
            </motion.div>
            
            <motion.h3 
              className="text-2xl font-medium text-white mb-4"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              No secret notes yet
            </motion.h3>
            <motion.p 
              className="text-gray-400 mb-8"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              Create your first confidential note
            </motion.p>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {secretNotes.map((note, index) => (
                <motion.div
                  key={note.id}
                  initial={{ opacity: 0, scale: 0.8, y: 20 }}
                  animate={{ 
                    opacity: 1, 
                    scale: 1, 
                    y: 0,
                    transition: {
                      delay: index * 0.05,
                      type: "spring",
                      stiffness: 260,
                      damping: 20
                    }
                  }}
                  exit={{ 
                    opacity: 0,
                    scale: 0.8,
                    filter: "blur(8px)",
                    transition: { duration: 0.3 }
                  }}
                  layout
                >
                  <NoteCard
                    note={note}
                    onView={handleViewNote}
                    onEdit={handleEditNote}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        <AnimatePresence>
          {showNewNoteForm && (
            <NoteForm
              isSecret
              onClose={() => setShowNewNoteForm(false)}
            />
          )}
        </AnimatePresence>

        <AnimatePresence>
          {viewNote && (
            <NoteForm
              note={viewNote}
              onClose={() => setViewNote(null)}
              isView
            />
          )}
        </AnimatePresence>

        <AnimatePresence>
          {editNote && (
            <NoteForm
              note={editNote}
              onClose={() => setEditNote(null)}
            />
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
