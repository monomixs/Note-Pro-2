import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus } from "lucide-react";
import { NoteCard } from "@/components/ui/note-card";
import { useNotes } from "@/context/note-context";
import { useSettings } from "@/context/settings-context";
import { NoteForm } from "@/components/ui/note-form";
import { Note } from "@shared/schema";

export default function Home() {
  const { publicNotes, isLoading } = useNotes();
  const { isDarkMode } = useSettings();
  const [showNewNoteForm, setShowNewNoteForm] = useState(false);
  const [viewNote, setViewNote] = useState<Note | null>(null);
  const [editNote, setEditNote] = useState<Note | null>(null);

  const handleViewNote = (note: Note) => {
    setViewNote(note);
  };

  const handleEditNote = (note: Note) => {
    setEditNote(note);
  };

  // Define animations
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: {
        when: "beforeChildren",
        staggerChildren: 0.1
      }
    }
  };

  const buttonVariants = {
    hidden: { 
      opacity: 0, 
      y: 20, 
      scale: 0.8
    },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: {
        type: "spring",
        damping: 12,
        stiffness: 200
      }
    },
    hover: { 
      scale: 1.05, 
      y: -5,
      boxShadow: "0 15px 30px rgba(14, 165, 233, 0.2)",
      transition: {
        type: "spring",
        damping: 10,
        stiffness: 300
      }
    },
    tap: { 
      scale: 0.95, 
      y: 0,
      transition: {
        type: "spring",
        damping: 15,
        stiffness: 400
      }
    }
  };

  const emptyStateVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        delay: 0.2,
        duration: 0.6,
        ease: [0.23, 1, 0.32, 1]
      }
    }
  };

  const skeletonVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (custom: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: custom * 0.1,
        duration: 0.5
      }
    })
  };

  return (
    <motion.main 
      className="container mx-auto px-4 pt-28 pb-10"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div 
        className="flex justify-center mb-12"
        variants={buttonVariants}
      >
        <motion.button
          className="bg-gradient-to-r from-sky-500 to-sky-600 text-black dark:text-white px-8 py-4 rounded-xl font-medium shadow-lg transition-all"
          variants={buttonVariants}
          whileHover="hover"
          whileTap="tap"
          onClick={() => setShowNewNoteForm(true)}
        >
          <span className="flex items-center">
            <Plus className="mr-2" size={24} />
            New Note
          </span>
        </motion.button>
      </motion.div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <motion.div 
              key={i} 
              className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} p-5 rounded-xl shadow-md h-40`}
              variants={skeletonVariants}
              custom={i}
              initial="hidden"
              animate="visible"
            >
              <div className="animate-pulse">
                <div className="h-4 bg-gray-700/30 rounded w-3/4 mb-3"></div>
                <div className="h-3 bg-gray-700/20 rounded w-full mb-2"></div>
                <div className="h-3 bg-gray-700/20 rounded w-5/6 mb-2"></div>
                <div className="h-3 bg-gray-700/20 rounded w-4/6 mb-4"></div>
                <div className="flex space-x-2">
                  <div className="h-6 w-6 bg-gray-700/30 rounded"></div>
                  <div className="h-6 w-6 bg-gray-700/30 rounded"></div>
                  <div className="h-6 w-6 bg-gray-700/30 rounded"></div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : publicNotes.length === 0 ? (
        <motion.div 
          className="text-center py-16"
          variants={emptyStateVariants}
        >
          <motion.h3 
            className="text-2xl font-medium mb-4"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            No notes yet
          </motion.h3>
          <motion.p 
            className="text-gray-600 dark:text-gray-400 mb-8"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            Create your first note to get started
          </motion.p>
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.5, type: "spring", stiffness: 200, damping: 15 }}
          >
            <motion.div 
              className="w-16 h-16 mx-auto bg-sky-100 dark:bg-sky-900/30 rounded-full flex items-center justify-center"
              animate={{ 
                scale: [1, 1.1, 1],
              }}
              transition={{ 
                repeat: Infinity, 
                repeatType: "reverse", 
                duration: 2,
                ease: "easeInOut"
              }}
            >
              <Plus className="text-sky-500" size={30} />
            </motion.div>
          </motion.div>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {publicNotes.map((note, index) => (
              <motion.div
                key={note.id}
                initial={{ opacity: 0, scale: 0.8, y: 20 }}
                animate={{ 
                  opacity: 1, 
                  scale: 1, 
                  y: 0,
                  transition: {
                    delay: index * 0.05,
                    type: "spring",
                    stiffness: 260,
                    damping: 20
                  }
                }}
                exit={{ 
                  opacity: 0,
                  scale: 0.8,
                  transition: { duration: 0.2 }
                }}
                layout
              >
                <NoteCard
                  note={note}
                  onView={handleViewNote}
                  onEdit={handleEditNote}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      <AnimatePresence>
        {showNewNoteForm && (
          <NoteForm
            onClose={() => setShowNewNoteForm(false)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {viewNote && (
          <NoteForm
            note={viewNote}
            onClose={() => setViewNote(null)}
            isView
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {editNote && (
          <NoteForm
            note={editNote}
            onClose={() => setEditNote(null)}
          />
        )}
      </AnimatePresence>
    </motion.main>
  );
}
