import { useState } from "react";
import { Note } from "@shared/schema";
import { motion, AnimatePresence } from "framer-motion";
import { Eye, Edit2, Trash2, Lock } from "lucide-react";
import { useNotes } from "@/context/note-context";
import { useSettings } from "@/context/settings-context";
import { ConfirmDialog } from "./confirm-dialog";

interface NoteCardProps {
  note: Note;
  onView: (note: Note) => void;
  onEdit: (note: Note) => void;
}

export function NoteCard({ note, onView, onEdit }: NoteCardProps) {
  const { deleteNote, updateNote } = useNotes();
  const { isDarkMode } = useSettings();
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showMakeSecretConfirm, setShowMakeSecretConfirm] = useState(false);

  const handleDeleteClick = () => {
    setShowDeleteConfirm(true);
  };

  const handleConfirmDelete = async () => {
    setIsDeleting(true);
    setShowDeleteConfirm(false);
    await deleteNote(note.id);
    setIsDeleting(false);
  };
  
  const handleMakeSecretClick = () => {
    setShowMakeSecretConfirm(true);
  };
  
  const handleConfirmMakeSecret = async () => {
    try {
      // Update the note to be secret and delete the original
      await updateNote(note.id, { ...note, isSecret: true });
      setShowMakeSecretConfirm(false);
    } catch (error) {
      console.error("Error making note secret:", error);
    }
  };

  // Use background color based on dark mode and border based on note type
  const cardBg = isDarkMode ? "bg-[#171717]" : "bg-white";
  const cardBorder = note.isSecret ? "border-2 border-red-500" : "border-2 border-sky-500";
  
  // Text color based on dark mode
  const textColor = isDarkMode ? "text-white" : "text-gray-900";
  const contentColor = isDarkMode ? "text-gray-300" : "text-gray-600";
  
  // Action button styling matching the card theme
  const actionBtnBg = "bg-gray-800";
  const actionBtnHoverBg = note.isSecret ? "hover:bg-red-500" : "hover:bg-sky-500";
  const actionBtnText = "text-gray-300";

  const cardVariants = {
    hidden: { opacity: 0, y: 50, scale: 0.9, rotateX: 10 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1, 
      rotateX: 0,
      transition: {
        type: "spring",
        damping: 15,
        stiffness: 200
      }
    },
    hover: { 
      y: -8, 
      scale: 1.02, 
      boxShadow: "0 15px 30px -5px rgba(0, 0, 0, 0.15), 0 15px 15px -5px rgba(0, 0, 0, 0.1)",
      transition: {
        type: "spring",
        damping: 15,
        stiffness: 300
      }
    },
    exit: { 
      opacity: 0, 
      scale: 0.8, 
      y: -100, 
      rotateX: -15,
      transition: {
        duration: 0.5,
        ease: [0.43, 0.13, 0.23, 0.96]
      }
    }
  };

  const buttonVariants = {
    hover: { 
      scale: 1.1, 
      rotate: 5,
      transition: {
        type: "spring",
        stiffness: 400,
        damping: 10
      }
    },
    tap: { scale: 0.9, rotate: 0 }
  };

  return (
    <>
      <motion.div
        className={`${cardBg} ${cardBorder} p-5 rounded-xl shadow-xl transition-all`}
        variants={cardVariants}
        initial="hidden"
        animate="visible"
        whileHover="hover"
        exit="exit"
        layout
      >
        <motion.h3 
          className={`font-heading font-semibold text-xl mb-2 ${textColor}`}
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          {note.title}
        </motion.h3>
        
        <motion.p 
          className={`${contentColor} mb-4 line-clamp-3 whitespace-pre-line`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          {note.content}
        </motion.p>
        
        <motion.div 
          className="flex space-x-2"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <motion.button
            className={`p-2 rounded-lg ${actionBtnBg} ${actionBtnHoverBg} hover:text-white transition-all ${actionBtnText}`}
            variants={buttonVariants}
            whileHover="hover"
            whileTap="tap"
            onClick={() => onView(note)}
          >
            <Eye size={16} />
          </motion.button>
          {!note.isSecret && (
            <motion.button
              className={`p-2 rounded-lg ${actionBtnBg} hover:bg-purple-500 hover:text-white transition-all ${actionBtnText}`}
              variants={buttonVariants}
              whileHover="hover"
              whileTap="tap"
              onClick={handleMakeSecretClick}
            >
              <Lock size={16} />
            </motion.button>
          )}
          <motion.button
            className={`p-2 rounded-lg ${actionBtnBg} ${actionBtnHoverBg} hover:text-white transition-all ${actionBtnText}`}
            variants={buttonVariants}
            whileHover="hover"
            whileTap="tap"
            onClick={() => onEdit(note)}
          >
            <Edit2 size={16} />
          </motion.button>
          <motion.button
            className={`p-2 rounded-lg ${actionBtnBg} hover:bg-red-500 hover:text-white transition-all ${actionBtnText}`}
            variants={buttonVariants}
            whileHover="hover"
            whileTap="tap"
            onClick={handleDeleteClick}
            disabled={isDeleting}
          >
            <Trash2 size={16} />
          </motion.button>
        </motion.div>
      </motion.div>

      <AnimatePresence>
        {showDeleteConfirm && (
          <ConfirmDialog
            title="Delete Note"
            message="Are you sure you want to delete this note? This action cannot be undone."
            confirmText="Delete"
            cancelText="Cancel"
            onConfirm={handleConfirmDelete}
            onCancel={() => setShowDeleteConfirm(false)}
          />
        )}
      </AnimatePresence>
      
      <AnimatePresence>
        {showMakeSecretConfirm && (
          <ConfirmDialog
            title="Make Note Secret"
            message="Are you sure you want to move this note to your secret notes? This will require PIN access to view in the future."
            confirmText="Make Secret"
            cancelText="Cancel"
            onConfirm={handleConfirmMakeSecret}
            onCancel={() => setShowMakeSecretConfirm(false)}
          />
        )}
      </AnimatePresence>
    </>
  );
}
