import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";
import { X, Moon, Sun, RotateCcw } from "lucide-react";
import { useSettings } from "@/context/settings-context";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";

interface SettingsPanelProps {
  onClose: () => void;
  isSecretMode?: boolean;
}

export function SettingsPanel({ onClose, isSecretMode = false }: SettingsPanelProps) {
  const { 
    fontSize, 
    setFontSize, 
    isDarkMode, 
    setIsDarkMode,
    resetSettings
  } = useSettings();
  const [isClosing, setIsClosing] = useState(false);

  useEffect(() => {
    document.body.classList.add("overflow-hidden");
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, []);

  const handleClose = () => {
    setIsClosing(true);
    // Delay actual closing to allow exit animation to play
    setTimeout(() => {
      onClose();
    }, 600);
  };

  const backdropVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1 },
    exit: { opacity: 0, transition: { duration: 0.6 } }
  };

  const modalVariants = {
    hidden: { 
      opacity: 0, 
      scale: 0.8, 
      y: 100,
      rotateY: 20,
      rotateX: 15 
    },
    visible: { 
      opacity: 1, 
      scale: 1,
      y: 0,
      rotateY: 0,
      rotateX: 0,
      transition: {
        type: "spring",
        damping: 20,
        stiffness: 300,
        when: "beforeChildren",
        staggerChildren: 0.1
      }
    },
    exit: { 
      opacity: 0,
      scale: 0.5,
      y: -200,
      rotateX: -30,
      transition: {
        duration: 0.5,
        ease: [0.43, 0.13, 0.23, 0.96],
        when: "afterChildren",
        staggerChildren: 0.05,
        staggerDirection: -1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { 
      opacity: 1, 
      x: 0,
      transition: {
        type: "spring",
        damping: 25,
        stiffness: 300
      }
    },
    exit: { 
      opacity: 0, 
      x: 20,
      transition: {
        duration: 0.3
      }
    }
  };

  const buttonVariants = {
    hover: { 
      scale: 1.05,
      boxShadow: "0 10px 20px rgba(0, 0, 0, 0.1)",
      transition: {
        type: "spring",
        stiffness: 400,
        damping: 10
      }
    },
    tap: { scale: 0.95 }
  };

  // Create a slider indicator component
  const SliderIndicator = ({ value }: { value: number }) => (
    <motion.div 
      className="flex justify-between space-x-1 mt-1"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.3 }}
    >
      {Array.from({ length: 7 }).map((_, i) => (
        <motion.div
          key={i}
          className={`h-1 rounded-full ${i <= (value - 14) ? "bg-sky-500" : "bg-gray-300 dark:bg-gray-700"}`}
          style={{ width: `${100 / 7}%` }}
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 0.1 * i, duration: 0.3 }}
        />
      ))}
    </motion.div>
  );

  return (
    <AnimatePresence mode="wait">
      {!isClosing && (
        <motion.div 
          className="fixed inset-0 z-50 flex items-center justify-center"
          variants={backdropVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
        >
          <motion.div 
            className="absolute inset-0 bg-black bg-opacity-60 backdrop-blur-md"
            onClick={handleClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
          
          <motion.div 
            className={`relative ${isDarkMode ? "bg-gray-800 text-white" : "bg-white text-gray-900"} rounded-xl p-8 w-full max-w-md mx-4 shadow-2xl overflow-hidden`}
            variants={modalVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
          >
            {/* Decorative elements */}
            <motion.div 
              className="absolute -top-20 -right-20 w-40 h-40 rounded-full bg-sky-500 opacity-10"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            />
            
            <motion.div 
              className="absolute -bottom-20 -left-20 w-40 h-40 rounded-full bg-pink-500 opacity-10"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            />
            
            <motion.h2 
              className="text-2xl font-heading font-bold mb-8 text-sky-600"
              variants={itemVariants}
            >
              Settings
            </motion.h2>
            
            <div className="space-y-8 relative z-10">
              <motion.div variants={itemVariants}>
                <h3 className="text-lg font-medium mb-4">Font Size</h3>
                <div className="px-1">
                  <Slider
                    min={14}
                    max={20}
                    step={1}
                    value={[fontSize]}
                    onValueChange={(value) => setFontSize(value[0])}
                    className="w-full"
                  />
                  <SliderIndicator value={fontSize} />
                  <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400 mt-1">
                    <span>Small</span>
                    <span>Large</span>
                  </div>
                </div>
              </motion.div>
              
              {!isSecretMode && (
                <motion.div variants={itemVariants}>
                  <h3 className="text-lg font-medium mb-4">Display Mode</h3>
                  <div className="flex items-center justify-center p-2">
                    <motion.div 
                      className="flex items-center space-x-4 px-5 py-3 rounded-xl bg-gray-100 dark:bg-gray-700"
                      whileHover={{ y: -2 }}
                    >
                      <motion.div 
                        animate={{ scale: isDarkMode ? 0.8 : 1.2, opacity: isDarkMode ? 0.5 : 1 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                      >
                        <Sun className={`${isDarkMode ? "text-gray-400" : "text-yellow-400"}`} size={24} />
                      </motion.div>
                      
                      <Switch 
                        checked={isDarkMode}
                        onCheckedChange={setIsDarkMode}
                        className="data-[state=checked]:bg-sky-600"
                      />
                      
                      <motion.div 
                        animate={{ scale: isDarkMode ? 1.2 : 0.8, opacity: isDarkMode ? 1 : 0.5 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                      >
                        <Moon className={`${isDarkMode ? "text-sky-400" : "text-gray-400"}`} size={24} />
                      </motion.div>
                    </motion.div>
                  </div>
                </motion.div>
              )}
              
              <motion.div variants={itemVariants}>
                <motion.button 
                  className="w-full py-3 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-all flex items-center justify-center"
                  onClick={resetSettings}
                  variants={buttonVariants}
                  whileHover="hover"
                  whileTap="tap"
                >
                  <RotateCcw className="mr-2" size={16} />
                  Reset to Defaults
                </motion.button>
              </motion.div>
            </div>
            
            <motion.button 
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 bg-gray-100 dark:bg-gray-700 p-1 rounded-full"
              onClick={handleClose}
              whileHover={{ scale: 1.2, rotate: 180 }}
              whileTap={{ scale: 0.9 }}
              transition={{ duration: 0.3 }}
            >
              <X size={20} />
            </motion.button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
