import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Note } from "@shared/schema";
import { useSettings } from "@/context/settings-context";
import { useNotes } from "@/context/note-context";
import { X } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface NoteFormProps {
  note?: Note;
  isSecret?: boolean;
  onClose: () => void;
  isView?: boolean;
}

export function NoteForm({ note, isSecret = false, onClose, isView = false }: NoteFormProps) {
  const [title, setTitle] = useState(note?.title || "");
  const [content, setContent] = useState(note?.content || "");
  const [isSaving, setIsSaving] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  const { isDarkMode } = useSettings();
  const { createNote, updateNote } = useNotes();
  
  useEffect(() => {
    document.body.classList.add("overflow-hidden");
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, []);

  const handleClose = () => {
    setIsClosing(true);
    // Delay actual closing to allow exit animation to play
    setTimeout(() => {
      onClose();
    }, 500);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim() || !content.trim()) {
      toast({
        title: "Error",
        description: "Please fill in both title and content fields",
        variant: "destructive"
      });
      return;
    }
    
    setIsSaving(true);

    try {
      if (note) {
        // Save and wait for the update to complete
        const updatedNote = await updateNote(note.id, { title, content, isSecret: note.isSecret });
        
        if (updatedNote) {
          toast({
            title: "Success",
            description: "Note updated successfully!"
          });
          
          // Wait a moment before closing to allow the UI to update
          setTimeout(() => {
            setIsClosing(true);
            setTimeout(() => {
              onClose();
            }, 500);
          }, 300);
        } else {
          throw new Error("Failed to update note.");
        }
      } else {
        // Save and wait for creation to complete
        const newNote = await createNote({ title, content, isSecret });
        
        if (newNote) {
          toast({
            title: "Success",
            description: "Note created successfully!"
          });
          
          // Wait a moment before closing to allow the UI to update
          setTimeout(() => {
            setIsClosing(true);
            setTimeout(() => {
              onClose();
            }, 500);
          }, 300);
        } else {
          throw new Error("Failed to create note.");
        }
      }
    } catch (error) {
      console.error("Error saving note:", error);
      toast({
        title: "Error",
        description: "Failed to save note. Please try again.",
        variant: "destructive"
      });
      setIsSaving(false);
    }
  };

  const backdropVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1 },
    exit: { opacity: 0, transition: { duration: 0.4 } }
  };

  const modalVariants = {
    hidden: { 
      opacity: 0, 
      scale: 0.8, 
      y: 50, 
      rotateX: 10
    },
    visible: { 
      opacity: 1, 
      scale: 1, 
      y: 0, 
      rotateX: 0,
      transition: {
        type: "spring",
        damping: 20,
        stiffness: 300,
        duration: 0.5
      }
    },
    exit: { 
      opacity: 0, 
      scale: 0.8, 
      y: -100, 
      rotateX: 15,
      transition: {
        duration: 0.5,
        ease: [0.43, 0.13, 0.23, 0.96]
      }
    }
  };

  const buttonVariants = {
    hover: { 
      scale: 1.05,
      transition: {
        type: "spring",
        stiffness: 400,
        damping: 10
      }
    },
    tap: { scale: 0.95 },
    disabled: { 
      opacity: 0.7, 
      scale: 1,
      cursor: "not-allowed"
    }
  };

  const formTitle = isView 
    ? "View Note" 
    : note 
      ? "Edit Note" 
      : isSecret 
        ? "Create Secret Note" 
        : "Create New Note";
  
  const inputFocusRing = "focus:ring-2 focus:ring-sky-500 focus:border-sky-500";

  return (
    <AnimatePresence mode="wait">
      {!isClosing && (
        <motion.div 
          className="fixed inset-0 z-50 flex items-center justify-center"
          variants={backdropVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
        >
          <motion.div 
            className="absolute inset-0 bg-black bg-opacity-60 backdrop-blur-md"
            onClick={isView ? handleClose : undefined}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
          
          <motion.div 
            className={`relative ${isDarkMode ? "bg-gradient-to-br from-gray-800 to-gray-900" : "bg-gradient-to-br from-white to-gray-50"} text-${isDarkMode ? "white" : "gray-900"} rounded-xl p-8 w-full max-w-lg mx-4 shadow-2xl overflow-hidden border-2 ${isSecret ? "border-red-500" : "border-sky-500"}`}
            variants={modalVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
          >
            {/* Decorative elements */}
            <motion.div 
              className={`absolute -top-20 -right-20 w-40 h-40 rounded-full ${isSecret ? "bg-red-500" : "bg-sky-500"} opacity-10`}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            />
            
            <motion.div 
              className="absolute -bottom-20 -left-20 w-40 h-40 rounded-full bg-pink-500 opacity-10"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            />
            
            <motion.h2 
              className={`text-2xl font-heading font-bold mb-6 ${isSecret ? "text-red-500" : "text-sky-600"}`}
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              {formTitle}
            </motion.h2>
            
            <form onSubmit={handleSubmit}>
              <motion.div 
                className="mb-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <label htmlFor="noteTitle" className="block mb-2 font-medium">Title</label>
                <input 
                  type="text" 
                  id="noteTitle" 
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className={`w-full px-4 py-2 ${isDarkMode ? "bg-gray-700 border-gray-600" : "bg-white border-gray-300"} border rounded-lg ${inputFocusRing} outline-none transition-all`}
                  disabled={isView || isSaving}
                  required
                />
              </motion.div>
              
              <motion.div 
                className="mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <label htmlFor="noteContent" className="block mb-2 font-medium">Content</label>
                <textarea 
                  id="noteContent" 
                  rows={5} 
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className={`w-full px-4 py-2 ${isDarkMode ? "bg-gray-700 border-gray-600" : "bg-white border-gray-300"} border rounded-lg ${inputFocusRing} outline-none resize-none transition-all`}
                  disabled={isView || isSaving}
                  required
                />
              </motion.div>
              
              {!isView && (
                <motion.div 
                  className="flex justify-end space-x-3"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  <motion.button 
                    type="button" 
                    className={`px-4 py-2 border ${isDarkMode ? "border-gray-700" : "border-gray-300"} rounded-lg ${isDarkMode ? "hover:bg-gray-700" : "hover:bg-gray-100"} transition-all`}
                    onClick={handleClose}
                    variants={buttonVariants}
                    whileHover="hover"
                    whileTap="tap"
                    disabled={isSaving}
                  >
                    Cancel
                  </motion.button>
                  <motion.button 
                    type="submit" 
                    className="px-4 py-2 bg-sky-600 text-white rounded-lg hover:bg-sky-700 transition-all"
                    variants={buttonVariants}
                    whileHover={isSaving ? "disabled" : "hover"}
                    whileTap={isSaving ? "disabled" : "tap"}
                    disabled={isSaving}
                  >
                    {isSaving ? "Saving..." : (note ? "Update Note" : "Save Note")}
                  </motion.button>
                </motion.div>
              )}
            </form>
            
            <motion.button 
              className={`absolute top-4 right-4 text-gray-400 ${isSecret ? "hover:text-red-500" : "hover:text-sky-500"}`}
              onClick={handleClose}
              whileHover={{ scale: 1.2, rotate: 90 }}
              whileTap={{ scale: 0.9 }}
              disabled={isSaving}
            >
              <X size={20} />
            </motion.button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
