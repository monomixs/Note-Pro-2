import { Settings, Lock, Unlock } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import { useSettings } from "@/context/settings-context";
import { SettingsPanel } from "./settings-panel";
import { PinPad } from "./pin-pad";

export default function NavBar() {
  const [location, setLocation] = useLocation();
  const { isDarkMode, setIsDarkMode } = useSettings();
  const [showSettings, setShowSettings] = useState(false);
  const [showPinPad, setShowPinPad] = useState(false);
  const [prevDarkMode, setPrevDarkMode] = useState(isDarkMode);
  
  const isSecretMode = location === "/secret";

  // Store the previous dark mode setting when entering secret mode
  useEffect(() => {
    if (isSecretMode) {
      setPrevDarkMode(isDarkMode);
      setIsDarkMode(true);
    } else if (prevDarkMode !== undefined) {
      setIsDarkMode(prevDarkMode);
    }
  }, [isSecretMode]);

  const handleSecretModeToggle = () => {
    if (isSecretMode) {
      setLocation("/");
    } else {
      setShowPinPad(true);
    }
  };

  const handlePinSuccess = () => {
    setShowPinPad(false);
    setLocation("/secret");
  };

  // Determine navbar styles based on mode
  const navbarBackground = isSecretMode
    ? "bg-opacity-80 bg-gray-900 backdrop-blur-md border border-gray-800"
    : isDarkMode
      ? "bg-opacity-70 bg-gray-900 backdrop-blur-md border border-gray-800"
      : "bg-opacity-70 bg-white backdrop-blur-md border border-gray-200";

  // Define animations
  const navbarVariants = {
    initial: { y: -50, opacity: 0 },
    animate: { 
      y: 0, 
      opacity: 1,
      transition: {
        type: "spring",
        damping: 20,
        stiffness: 300
      }
    },
    exit: { 
      y: -50, 
      opacity: 0,
      transition: {
        duration: 0.3
      }
    }
  };

  const logoVariants = {
    initial: { scale: 0.8, opacity: 0 },
    animate: { 
      scale: 1, 
      opacity: 1,
      transition: {
        type: "spring",
        damping: 15,
        stiffness: 300,
        delay: 0.2
      }
    }
  };

  const buttonVariants = {
    initial: { scale: 0, opacity: 0 },
    animate: (custom: number) => ({
      scale: 1,
      opacity: 1,
      transition: {
        type: "spring",
        damping: 15,
        stiffness: 300,
        delay: 0.3 + (custom * 0.1)
      }
    }),
    hover: { 
      scale: 1.2, 
      rotate: 15,
      transition: {
        type: "spring",
        stiffness: 500,
        damping: 10
      }
    },
    tap: { scale: 0.9, rotate: 0 }
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50">
        <motion.nav 
          className={`mx-4 mt-4 px-5 py-4 rounded-xl flex justify-between items-center shadow-xl ${navbarBackground}`}
          variants={navbarVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          layoutId="navbar"
        >
          <motion.div 
            className="flex items-center"
            variants={logoVariants}
            initial="initial"
            animate="animate"
          >
            <h1 className={`text-2xl font-heading font-bold ${isSecretMode ? "text-red-500" : "text-sky-600"}`}>
              Note Pro 2
              {isSecretMode && (
                <motion.span 
                  className="ml-2 text-xs text-red-400 align-top"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                >
                  SECRET MODE
                </motion.span>
              )}
            </h1>
          </motion.div>
          <div className="flex items-center space-x-4">
            <motion.button 
              className={`p-2 rounded-full ${isDarkMode ? "hover:bg-gray-800" : "hover:bg-sky-100"} transition-all`}
              variants={buttonVariants}
              custom={0}
              initial="initial"
              animate="animate"
              whileHover="hover"
              whileTap="tap"
              onClick={() => setShowSettings(true)}
            >
              <Settings className="text-sky-600" size={20} />
            </motion.button>
            <motion.button 
              className={`p-2 rounded-full ${isDarkMode ? "hover:bg-gray-800" : "hover:bg-sky-100"} transition-all`}
              variants={buttonVariants}
              custom={1}
              initial="initial"
              animate="animate"
              whileHover="hover"
              whileTap="tap"
              onClick={handleSecretModeToggle}
            >
              {isSecretMode ? (
                <Unlock className="text-red-500" size={20} />
              ) : (
                <Lock className="text-sky-600" size={20} />
              )}
            </motion.button>
          </div>
        </motion.nav>
      </header>

      <AnimatePresence mode="wait">
        {showSettings && (
          <SettingsPanel onClose={() => setShowSettings(false)} isSecretMode={isSecretMode} />
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        {showPinPad && (
          <PinPad onSuccess={handlePinSuccess} onClose={() => setShowPinPad(false)} />
        )}
      </AnimatePresence>
    </>
  );
}
