import { motion, AnimatePresence } from "framer-motion";
import { useEffect } from "react";
import { X } from "lucide-react";

interface ConfirmDialogProps {
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  onConfirm: () => void;
  onCancel: () => void;
  isSecretMode?: boolean;
}

export function ConfirmDialog({
  title,
  message,
  confirmText = "Confirm",
  cancelText = "Cancel",
  onConfirm,
  onCancel,
  isSecretMode = false
}: ConfirmDialogProps) {
  useEffect(() => {
    // Prevent background scrolling when dialog is open
    document.body.classList.add("overflow-hidden");
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, []);

  const backdropVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1 },
    exit: { opacity: 0, transition: { duration: 0.4 } }
  };

  const modalVariants = {
    hidden: { 
      opacity: 0,
      scale: 0.5,
      y: 100,
      rotateX: -15
    },
    visible: { 
      opacity: 1, 
      scale: 1,
      y: 0,
      rotateX: 0,
      transition: {
        type: "spring",
        damping: 15,
        stiffness: 300,
        duration: 0.5
      }
    },
    exit: { 
      opacity: 0,
      scale: 0.8,
      y: -100,
      rotateX: 15,
      transition: {
        duration: 0.4,
        ease: [0.4, 0, 0.2, 1]
      }
    }
  };

  const buttonVariants = {
    hover: { 
      scale: 1.05,
      transition: {
        type: "spring",
        stiffness: 400,
        damping: 10
      }
    },
    tap: { scale: 0.95 }
  };

  return (
    <AnimatePresence>
      <motion.div 
        className="fixed inset-0 z-50 flex items-center justify-center"
        variants={backdropVariants}
        initial="hidden"
        animate="visible"
        exit="exit"
      >
        <motion.div 
          className="absolute inset-0 bg-black bg-opacity-60 backdrop-blur-md"
          onClick={onCancel}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        />
        
        <motion.div 
          className={`relative bg-[#171717] text-white rounded-xl p-6 w-full max-w-md mx-4 shadow-2xl border-2 ${isSecretMode ? "border-red-500" : "border-sky-500"}`}
          variants={modalVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
        >
          <motion.h2 
            className={`text-2xl font-heading font-bold mb-3 text-white ${isSecretMode ? "text-red-500" : "text-sky-500"}`}
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            {title}
          </motion.h2>
          
          <motion.p 
            className="mb-6 text-gray-300"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            {message}
          </motion.p>
          
          <motion.div 
            className="flex justify-end space-x-3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <motion.button 
              type="button" 
              className="px-4 py-2 border border-gray-600 rounded-lg hover:bg-gray-700 text-gray-300"
              onClick={onCancel}
              variants={buttonVariants}
              whileHover="hover"
              whileTap="tap"
            >
              {cancelText}
            </motion.button>
            <motion.button 
              type="button" 
              className={`px-4 py-2 text-white rounded-lg ${isSecretMode ? "bg-red-500 hover:bg-red-600" : "bg-sky-500 hover:bg-sky-600"}`}
              onClick={onConfirm}
              variants={buttonVariants}
              whileHover="hover"
              whileTap="tap"
            >
              {confirmText}
            </motion.button>
          </motion.div>
          
          <motion.button 
            className={`absolute top-4 right-4 text-gray-400 ${isSecretMode ? "hover:text-red-500" : "hover:text-sky-500"}`}
            onClick={onCancel}
            whileHover={{ scale: 1.2, rotate: 90 }}
            whileTap={{ scale: 0.9 }}
          >
            <X size={20} />
          </motion.button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}