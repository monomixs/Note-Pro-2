import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Delete, ShieldCheck, ShieldAlert, KeyRound } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { useSettings } from "@/context/settings-context";

interface PinPadProps {
  onSuccess: () => void;
  onClose: () => void;
}

export function PinPad({ onSuccess, onClose }: PinPadProps) {
  const [pin, setPin] = useState("");
  const [error, setError] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  const { isDarkMode } = useSettings();

  useEffect(() => {
    document.body.classList.add("overflow-hidden");
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, []);

  const handlePinInput = (digit: string) => {
    if (pin.length < 4 && !isVerifying && !isSuccess) {
      const newPin = pin + digit;
      setPin(newPin);
      
      if (newPin.length === 4) {
        verifyPin(newPin);
      }
    }
  };

  const handleBackspace = () => {
    if (pin.length > 0 && !isVerifying && !isSuccess) {
      setPin(pin.substring(0, pin.length - 1));
      setError(false);
    }
  };

  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      onClose();
    }, 600);
  };

  const verifyPin = async (pinToVerify: string) => {
    setIsVerifying(true);
    
    try {
      const res = await apiRequest("POST", "/api/verify-pin", { pin: pinToVerify });
      const data = await res.json();
      
      if (data.success) {
        setIsSuccess(true);
        setTimeout(() => {
          onSuccess();
        }, 800);
      } else {
        setError(true);
        setTimeout(() => {
          setPin("");
          setError(false);
          setIsVerifying(false);
        }, 800);
      }
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to verify PIN. Please try again.",
        variant: "destructive",
      });
      setPin("");
      setIsVerifying(false);
    }
  };

  const backdropVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1 },
    exit: { opacity: 0, transition: { duration: 0.6 } }
  };

  const modalVariants = {
    hidden: { 
      opacity: 0, 
      scale: 0.8, 
      y: 50, 
      rotateX: 15
    },
    visible: { 
      opacity: 1, 
      scale: 1, 
      y: 0, 
      rotateX: 0,
      transition: {
        type: "spring",
        damping: 20,
        stiffness: 300,
        duration: 0.5
      }
    },
    exit: { 
      opacity: 0, 
      scale: 0.8, 
      y: -100, 
      rotateX: -30,
      transition: {
        duration: 0.5,
        ease: [0.43, 0.13, 0.23, 0.96]
      }
    },
    error: {
      x: [0, -10, 10, -10, 10, 0],
      transition: { 
        duration: 0.5, 
        ease: "easeInOut" 
      }
    },
    success: {
      scale: 1.05,
      boxShadow: "0 0 30px rgba(14, 165, 233, 0.6)",
      transition: { 
        duration: 0.5 
      }
    }
  };

  const buttonVariants = {
    hidden: (custom: number) => ({
      opacity: 0,
      y: 20,
      scale: 0.8,
      transition: {
        delay: 0.1 * custom
      }
    }),
    visible: (custom: number) => ({
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        delay: 0.05 * custom,
        type: "spring",
        damping: 15,
        stiffness: 300
      }
    }),
    hover: { 
      scale: 1.1,
      backgroundColor: isDarkMode ? "rgb(7, 89, 133)" : "rgb(224, 242, 254)",
      transition: {
        type: "spring",
        stiffness: 500,
        damping: 10
      }
    },
    tap: { 
      scale: 0.95
    }
  };

  const dotVariants = {
    empty: { 
      scale: 1,
      backgroundColor: "transparent",
      borderColor: "#D1D5DB"
    },
    filled: { 
      scale: 1.2,
      backgroundColor: "rgb(14, 165, 233)",
      borderColor: "rgb(14, 165, 233)",
      transition: {
        type: "spring",
        stiffness: 500,
        damping: 15
      }
    },
    error: {
      scale: [1, 1.2, 1],
      backgroundColor: "rgb(239, 68, 68)",
      borderColor: "rgb(239, 68, 68)",
      transition: {
        duration: 0.3,
        repeat: 1
      }
    },
    success: (i: number) => ({
      scale: 1.2,
      backgroundColor: "rgb(34, 197, 94)",
      borderColor: "rgb(34, 197, 94)",
      transition: {
        delay: i * 0.1,
        duration: 0.3
      }
    })
  };

  return (
    <AnimatePresence mode="wait">
      {!isClosing && (
        <motion.div 
          className="fixed inset-0 z-50 flex items-center justify-center"
          variants={backdropVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
        >
          <motion.div 
            className="absolute inset-0 bg-black bg-opacity-70 backdrop-blur-lg"
            onClick={!isVerifying ? handleClose : undefined}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
          
          <motion.div 
            className={`relative ${isDarkMode ? "bg-gray-800" : "bg-white"} rounded-2xl p-8 w-full max-w-sm mx-4 shadow-2xl overflow-hidden`}
            variants={modalVariants}
            initial="hidden"
            animate={error ? "error" : isSuccess ? "success" : "visible"}
            exit="exit"
          >
            {/* Decorative background shapes */}
            <motion.div 
              className="absolute -top-20 -right-20 w-40 h-40 rounded-full bg-sky-500 opacity-10"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.6 }}
            />
            
            <motion.div 
              className="absolute -bottom-20 -left-20 w-40 h-40 rounded-full bg-pink-500 opacity-10"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            />

            {/* Header with icon */}
            <motion.div 
              className="mb-6 flex justify-center"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <motion.div
                className="bg-sky-100 dark:bg-sky-900/30 p-3 rounded-full"
                animate={
                  isSuccess 
                    ? { 
                        scale: [1, 1.2, 1],
                        boxShadow: [
                          "0 0 0 0 rgba(14, 165, 233, 0.7)",
                          "0 0 0 15px rgba(14, 165, 233, 0)",
                          "0 0 0 0 rgba(14, 165, 233, 0)"
                        ]
                      } 
                    : error 
                      ? { 
                          rotate: [-5, 5, -5, 5, 0]
                        } 
                      : { 
                          scale: [1, 1.05, 1],
                        }
                }
                transition={{ 
                  duration: isSuccess ? 1.5 : error ? 0.4 : 2,
                  repeat: isSuccess ? 0 : error ? 0 : Infinity,
                  repeatType: "loop"
                }}
              >
                {isSuccess ? (
                  <ShieldCheck className="text-green-500" size={32} />
                ) : error ? (
                  <ShieldAlert className="text-red-500" size={32} />
                ) : (
                  <KeyRound className="text-sky-500" size={32} />
                )}
              </motion.div>
            </motion.div>
            
            <motion.h2 
              className="text-2xl font-heading font-bold mb-4 text-center text-sky-600"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              {isSuccess ? "Access Granted" : error ? "Invalid PIN" : "Enter Secret PIN"}
            </motion.h2>
            
            {/* PIN dots */}
            <motion.div 
              className="flex justify-center mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <div className="flex space-x-4">
                {Array.from({ length: 4 }).map((_, index) => (
                  <motion.div 
                    key={index}
                    className="w-5 h-5 rounded-full border-2"
                    variants={dotVariants}
                    initial="empty"
                    animate={
                      isSuccess 
                        ? "success" 
                        : error && index < pin.length 
                          ? "error" 
                          : index < pin.length 
                            ? "filled" 
                            : "empty"
                    }
                    custom={index}
                  />
                ))}
              </div>
            </motion.div>
            
            {/* PIN pad grid */}
            <motion.div 
              className="grid grid-cols-3 gap-4 mb-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num, index) => (
                <motion.button
                  key={num}
                  className={`w-16 h-16 ${
                    isDarkMode ? "bg-gray-700 text-white" : "bg-gray-100 text-gray-800"
                  } rounded-2xl flex items-center justify-center text-xl font-medium shadow-md`}
                  onClick={() => handlePinInput(num.toString())}
                  variants={buttonVariants}
                  initial="hidden"
                  animate="visible"
                  whileHover={isVerifying || isSuccess ? undefined : "hover"}
                  whileTap={isVerifying || isSuccess ? undefined : "tap"}
                  custom={index}
                  disabled={isVerifying || isSuccess}
                >
                  {num}
                </motion.button>
              ))}
              <motion.button
                className={`w-16 h-16 ${
                  isDarkMode ? "bg-gray-700 text-white" : "bg-gray-100 text-gray-800"
                } rounded-2xl flex items-center justify-center text-xl font-medium shadow-md`}
                onClick={() => handlePinInput("0")}
                variants={buttonVariants}
                initial="hidden"
                animate="visible"
                whileHover={isVerifying || isSuccess ? undefined : "hover"}
                whileTap={isVerifying || isSuccess ? undefined : "tap"}
                custom={9}
                disabled={isVerifying || isSuccess}
              >
                0
              </motion.button>
              <motion.button
                className={`w-16 h-16 ${
                  isDarkMode ? "bg-gray-700 text-white" : "bg-gray-100 text-gray-800"
                } rounded-2xl flex items-center justify-center text-xl font-medium shadow-md`}
                onClick={handleBackspace}
                variants={buttonVariants}
                initial="hidden"
                animate="visible"
                whileHover={isVerifying || isSuccess ? undefined : "hover"}
                whileTap={isVerifying || isSuccess ? undefined : "tap"}
                custom={10}
                disabled={isVerifying || isSuccess}
              >
                <Delete size={20} />
              </motion.button>
            </motion.div>
            
            {/* Cancel button */}
            <motion.div 
              className="flex justify-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
            >
              <motion.button 
                className={`px-6 py-3 border ${
                  isDarkMode ? "border-gray-700 text-white" : "border-gray-300 text-gray-700"
                } rounded-lg transition-colors ${
                  !isVerifying && !isSuccess
                    ? isDarkMode 
                      ? "hover:bg-gray-700" 
                      : "hover:bg-gray-100"
                    : ""
                }`}
                onClick={!isVerifying ? handleClose : undefined}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                disabled={isVerifying}
              >
                {isSuccess ? "Continue" : "Cancel"}
              </motion.button>
            </motion.div>

            {/* Success animation */}
            {isSuccess && (
              <motion.div
                className="absolute inset-0 bg-green-500 bg-opacity-10 backdrop-blur-sm flex items-center justify-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ 
                    type: "spring",
                    damping: 10,
                    stiffness: 100 
                  }}
                >
                  <ShieldCheck className="text-green-500 w-20 h-20" />
                </motion.div>
              </motion.div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
