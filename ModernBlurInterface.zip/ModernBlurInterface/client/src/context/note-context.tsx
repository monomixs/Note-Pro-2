import { createContext, useContext, ReactNode, useState, useEffect } from "react";
import { Note, InsertNote, UpdateNote } from "@shared/schema";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";

interface NoteContextType {
  publicNotes: Note[];
  secretNotes: Note[];
  isLoading: boolean;
  createNote: (note: Omit<InsertNote, "id">) => Promise<Note>;
  updateNote: (id: number, note: UpdateNote) => Promise<Note | undefined>;
  deleteNote: (id: number) => Promise<boolean>;
}

const NoteContext = createContext<NoteContextType | undefined>(undefined);

export function NoteProvider({ children }: { children: ReactNode }) {
  // Fetch public notes
  const { 
    data: publicNotes = [] as Note[], 
    isLoading: isLoadingPublic,
    refetch: refetchPublic
  } = useQuery<Note[]>({
    queryKey: ["/api/notes"],
  });

  // Fetch secret notes
  const { 
    data: secretNotes = [] as Note[], 
    isLoading: isLoadingSecret,
    refetch: refetchSecret
  } = useQuery<Note[]>({
    queryKey: ["/api/notes/secret"],
  });

  // Create note mutation
  const createNoteMutation = useMutation({
    mutationFn: async (noteData: Omit<InsertNote, "id">) => {
      const res = await apiRequest("POST", "/api/notes", noteData);
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Success",
        description: "Note created successfully!",
      });
      
      if (data.isSecret) {
        queryClient.invalidateQueries({ queryKey: ["/api/notes/secret"] });
        refetchSecret();
      } else {
        queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
        refetchPublic();
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create note. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update note mutation
  const updateNoteMutation = useMutation({
    mutationFn: async ({ id, note }: { id: number; note: UpdateNote }) => {
      const res = await apiRequest("PUT", `/api/notes/${id}`, note);
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Success",
        description: "Note updated successfully!",
      });
      
      if (data.isSecret) {
        queryClient.invalidateQueries({ queryKey: ["/api/notes/secret"] });
        refetchSecret();
      } else {
        queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
        refetchPublic();
      }
    },
    onError: (error) => {
      console.error("Update error:", error);
      toast({
        title: "Error",
        description: "Failed to update note. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Delete note mutation
  const deleteNoteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/notes/${id}`);
      return id;
    },
    onSuccess: (id) => {
      toast({
        title: "Success",
        description: "Note deleted successfully!",
      });
      
      // Since we don't know if it was a secret note or not, invalidate both queries
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notes/secret"] });
      // And refetch both
      refetchPublic();
      refetchSecret();
    },
    onError: (error) => {
      console.error("Delete error:", error);
      toast({
        title: "Error",
        description: "Failed to delete note. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createNote = async (noteData: Omit<InsertNote, "id">): Promise<Note> => {
    return createNoteMutation.mutateAsync(noteData);
  };

  const updateNote = async (id: number, noteData: UpdateNote): Promise<Note | undefined> => {
    return updateNoteMutation.mutateAsync({ id, note: noteData });
  };

  const deleteNote = async (id: number): Promise<boolean> => {
    await deleteNoteMutation.mutateAsync(id);
    return true;
  };

  // Sort notes to show newest first (assuming newer notes have higher IDs)
  const sortedPublicNotes = [...publicNotes].sort((a, b) => b.id - a.id);
  const sortedSecretNotes = [...secretNotes].sort((a, b) => b.id - a.id);

  return (
    <NoteContext.Provider
      value={{
        publicNotes: sortedPublicNotes as Note[],
        secretNotes: sortedSecretNotes as Note[],
        isLoading: isLoadingPublic || isLoadingSecret,
        createNote,
        updateNote,
        deleteNote,
      }}
    >
      {children}
    </NoteContext.Provider>
  );
}

export function useNotes() {
  const context = useContext(NoteContext);
  if (context === undefined) {
    throw new Error("useNotes must be used within a NoteProvider");
  }
  return context;
}
