import { createContext, useContext, ReactNode, useState, useEffect } from "react";

interface SettingsContextType {
  fontSize: number;
  setFontSize: (size: number) => void;
  isDarkMode: boolean;
  setIsDarkMode: (isDark: boolean) => void;
  resetSettings: () => void;
}

const defaultSettings = {
  fontSize: 16,
  isDarkMode: false,
};

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState(() => {
    try {
      const savedSettings = localStorage.getItem("notePro2Settings");
      return savedSettings ? { ...defaultSettings, ...JSON.parse(savedSettings) } : defaultSettings;
    } catch (error) {
      // If there's an error parsing the settings, use defaults
      return defaultSettings;
    }
  });

  const { fontSize, isDarkMode } = settings;

  useEffect(() => {
    try {
      localStorage.setItem("notePro2Settings", JSON.stringify(settings));
    } catch (error) {
      console.error("Could not save settings to localStorage", error);
    }
    
    // Apply font size to the document
    document.documentElement.style.fontSize = `${fontSize}px`;
    
    // Update favicon based on theme
    const favicon = document.querySelector('link[rel="icon"]') as HTMLLinkElement;
    if (favicon) {
      favicon.href = "https://img.icons8.com/fluency/48/notepad.png";
    }
    
  }, [settings]);

  const setFontSize = (size: number) => {
    setSettings((prev: typeof defaultSettings) => ({ ...prev, fontSize: size }));
  };

  const setIsDarkMode = (isDark: boolean) => {
    setSettings((prev: typeof defaultSettings) => ({ ...prev, isDarkMode: isDark }));
  };

  const resetSettings = () => {
    setSettings(defaultSettings);
  };

  return (
    <SettingsContext.Provider
      value={{
        fontSize,
        setFontSize,
        isDarkMode,
        setIsDarkMode,
        resetSettings,
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error("useSettings must be used within a SettingsProvider");
  }
  return context;
}
