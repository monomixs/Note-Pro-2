import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import SecretNotes from "@/pages/secret-notes";
import NavBar from "@/components/ui/nav-bar";
import { SettingsProvider } from "./context/settings-context";
import { NoteProvider } from "./context/note-context";
import { useSettings } from "./context/settings-context";

// The router component to handle different routes
function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/secret" component={SecretNotes} />
      <Route component={NotFound} />
    </Switch>
  );
}

// Theme-aware component that uses settings context
function ThemedApp() {
  const { isDarkMode } = useSettings();
  
  return (
    <div className={`${isDarkMode ? "dark" : "light"}`}>
      <div className={`min-h-screen transition-colors ${isDarkMode ? "bg-black text-white" : "bg-gray-50 text-gray-900"}`}>
        <NavBar />
        <main className="pt-20">
          <Router />
        </main>
        <Toaster />
      </div>
    </div>
  );
}

// Main App component that provides context
function App() {
  return (
    <SettingsProvider>
      <NoteProvider>
        <ThemedApp />
      </NoteProvider>
    </SettingsProvider>
  );
}

export default App;
